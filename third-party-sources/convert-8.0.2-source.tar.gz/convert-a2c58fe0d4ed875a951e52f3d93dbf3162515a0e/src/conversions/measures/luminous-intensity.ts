import { expandMacro, Macros } from '../macros/macros.ts';
import { type Measure, MeasureKind } from '../types.ts';

export const luminousIntensity: Measure = {
	kind: MeasureKind.LuminousIntensity,
	best: ['cd'],
	units: [
		// https://en.wikipedia.org/wiki/Candela
		{ names: ['candela'], symbols: ['cd'], ratio: 1 },
		...expandMacro(Macros.si, { names: ['candela'], symbols: ['cd'], ratio: 1 }),

		// https://en.wikipedia.org/wiki/Candlepower
		{ names: ['candlepower'], symbols: ['cp', 'CP'], ratio: 1 },

		// https://en.wikipedia.org/wiki/Hefner_lamp
		{ names: ['hefnerkerze'], symbols: ['HK'], ratio: 0.92 },
	],
};

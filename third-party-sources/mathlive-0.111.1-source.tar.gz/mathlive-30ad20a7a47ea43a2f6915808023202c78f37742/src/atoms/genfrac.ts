import type { LatexValue, MathstyleName, Style } from '../public/core-types';

import { Atom } from '../core/atom-class';
import { Box } from '../core/box';
import { VBox } from '../core/v-box';
import { makeCustomSizedDelim, makeNullDelimiter } from '../core/delimiters';
import { Context } from '../core/context';
import { AXIS_HEIGHT } from '../core/font-metrics';
import type { AtomJson } from '../core/types';
import { _MathEnvironment } from '../core/math-environment';

export type GenfracOptions = {
  continuousFraction?: boolean;
  align?: 'left' | 'right' | 'center';
  numerPrefix?: string;
  denomPrefix?: string;
  leftDelim?: string;
  rightDelim?: string;
  hasBarLine?: boolean;
  /** The thickness of the fraction bar. If undefined, use the default
   * rule thickness of the font. Used by `\genfrac`. */
  barThickness?: LatexValue;
  mathstyleName?: MathstyleName;
  style?: Style;
};

/**
 * Genfrac -- Generalized Fraction
 *
 * Decompose fractions, binomials, and in general anything made
 * of a numerator and denominator, optionally separated by a fraction bar,
 * and optionally surrounded by delimiters (parentheses, brackets, etc...).
 *
 * Depending on the type of fraction the mathstyle is either
 * displaystyle or textstyle. This value can also be set to 'auto',
 * to indicate it should use the current mathstyle
 */
export class GenfracAtom extends Atom {
  readonly hasBarLine: boolean;
  readonly leftDelim?: string;
  readonly rightDelim?: string;
  readonly barThickness?: LatexValue;
  readonly mathstyleName?: MathstyleName;
  private readonly continuousFraction: boolean;
  private readonly align: 'left' | 'right' | 'center';
  private readonly numerPrefix?: string;
  private readonly denomPrefix?: string;

  constructor(
    above: readonly Atom[],
    below: readonly Atom[],
    options: GenfracOptions
  ) {
    super({
      ...options,
      type: 'genfrac',
      displayContainsHighlight: true,
    });
    this.above = above;
    this.below = below;
    this.hasBarLine = options?.hasBarLine ?? true;
    this.continuousFraction = options?.continuousFraction ?? false;
    this.align = options?.align ?? 'center';
    this.numerPrefix = options?.numerPrefix;
    this.denomPrefix = options?.denomPrefix;
    this.mathstyleName = options?.mathstyleName;
    this.leftDelim = options?.leftDelim;
    this.rightDelim = options?.rightDelim;
    this.barThickness = options?.barThickness;
  }

  static fromJson(json: AtomJson): GenfracAtom {
    return new GenfracAtom(
      json.above,
      json.below,
      json as any as GenfracOptions
    );
  }

  toJson(): AtomJson {
    const options: GenfracOptions = {};
    if (this.continuousFraction) options.continuousFraction = true;
    if (this.align !== 'center') options.align = this.align;
    if (this.numerPrefix) options.numerPrefix = this.numerPrefix;
    if (this.denomPrefix) options.denomPrefix = this.denomPrefix;
    if (this.leftDelim) options.leftDelim = this.leftDelim;
    if (this.rightDelim) options.rightDelim = this.rightDelim;
    if (!this.hasBarLine) options.hasBarLine = false;
    if (this.barThickness) options.barThickness = this.barThickness;
    if (this.mathstyleName) options.mathstyleName = this.mathstyleName;
    return { ...super.toJson(), ...options };
  }

  // The order of the children, which is used for keyboard navigation order,
  // may be customized for fractions...
  get children(): readonly Atom[] {
    if (this._children) return this._children;

    const result: Atom[] = [];
    if (_MathEnvironment.fractionNavigationOrder === 'denominator-numerator') {
      for (const x of this.below!) {
        result.push(...x.children);
        result.push(x);
      }
      for (const x of this.above!) {
        result.push(...x.children);
        result.push(x);
      }
    } else {
      for (const x of this.above!) {
        result.push(...x.children);
        result.push(x);
      }
      for (const x of this.below!) {
        result.push(...x.children);
        result.push(x);
      }
    }

    this._children = result;
    return result;
  }

  render(context: Context): Box | null {
    const fracContext = new Context(
      { parent: context, mathstyle: this.mathstyleName },
      this.style
    );
    const metrics = fracContext.metrics;

    const numContext = new Context(
      {
        parent: fracContext,
        mathstyle: this.continuousFraction ? '' : 'numerator',
      },
      this.style
    );
    const numerBox = this.numerPrefix
      ? new Box(
          [new Box(this.numerPrefix), Atom.createBox(numContext, this.above)],
          { isTight: numContext.isTight, type: 'ignore' }
        )
      : (Atom.createBox(numContext, this.above, { type: 'ignore' }) ??
        new Box(null, { type: 'ignore' }));

    const denomContext = new Context(
      {
        parent: fracContext,
        mathstyle: this.continuousFraction ? '' : 'denominator',
      },
      this.style
    );
    const denomBox = this.denomPrefix
      ? new Box([
          new Box(this.denomPrefix),
          Atom.createBox(denomContext, this.below, { type: 'ignore' }),
        ])
      : (Atom.createBox(denomContext, this.below, { type: 'ignore' }) ??
        new Box(null, { type: 'ignore' }));

    let ruleThickness = 0;
    if (this.hasBarLine) {
      ruleThickness = this.barThickness
        ? fracContext.toEm(this.barThickness)
        : metrics.defaultRuleThickness;
    }

    // Rule 15b from TeXBook Appendix G, p.444
    //
    // 15b. If C > T, set u ← σ8 and v ← σ11. Otherwise set u ← σ9 or σ10,according
    // as θ ̸= 0 or θ = 0, and set v ← σ12. (The fraction will be typeset with
    // its numerator shifted up by an amount u with respect to the current
    // baseline, and with the denominator shifted down by v, unless the boxes
    // are unusually large.)
    let numerShift: number;
    let clearance = 0;
    let denomShift: number;
    if (fracContext.isDisplayStyle) {
      numerShift = numContext.metrics.num1; // Set u ← σ8
      clearance = ruleThickness > 0 ? 3 * ruleThickness : 7 * ruleThickness;
      denomShift = denomContext.metrics.denom1; // V ← σ11
    } else {
      if (ruleThickness > 0) {
        numerShift = numContext.metrics.num2; // U ← σ9
        clearance = ruleThickness; //  Φ ← θ
      } else {
        numerShift = numContext.metrics.num3; // U ← σ10
        clearance = 3 * metrics.defaultRuleThickness; // Φ ← 3 ξ8
      }

      denomShift = denomContext.metrics.denom2; // V ← σ12
    }

    const classes: string[] = [];
    if (this.isSelected) classes.push('ML__selected');
    const numerDepth = numerBox.depth;
    const denomHeight = denomBox.height;
    let frac: Box;
    if (ruleThickness <= 0) {
      // Rule 15c from Appendix G
      // No bar line between numerator and denominator
      const candidateClearance =
        numerShift - numerDepth - (denomHeight - denomShift);
      if (candidateClearance < clearance) {
        numerShift += (clearance - candidateClearance) / 2;
        denomShift += (clearance - candidateClearance) / 2;
      }

      frac = new VBox({
        individualShift: [
          {
            box: numerBox,
            shift: -numerShift,
            classes: [...classes, align(this.align)],
          },
          {
            box: denomBox,
            shift: denomShift,
            classes: [...classes, align(this.align)],
          },
        ],
      }).wrap(fracContext);
    } else {
      // Rule 15d from Appendix G of the TeXBook.
      // There is a bar line between the numerator and the denominator

      const fracLine = new Box(null, {
        classes: 'ML__frac-line',
        mode: this.mode,
        style: this.style,
      });
      fracLine.softWidth = Math.max(numerBox.width, denomBox.width);
      fracLine.height = ruleThickness / 2;
      fracLine.depth = ruleThickness / 2;
      // The CSS rule for `.ML__frac-line` draws a bar of a fixed default
      // thickness. A custom thickness overrides it with CSS variables: the
      // bar is as thick as the element and has no vertical offset.
      if (this.barThickness) {
        fracLine.setStyle('--frac-line-thickness' as any, ruleThickness, 'em');
        fracLine.setStyle('--frac-line-margin' as any, '0');
      }

      const numerLine = AXIS_HEIGHT + ruleThickness / 2;
      if (numerShift < clearance + numerDepth + numerLine)
        numerShift = clearance + numerDepth + numerLine;

      const denomLine = AXIS_HEIGHT - ruleThickness / 2;
      if (denomShift < clearance + denomHeight - denomLine)
        denomShift = clearance + denomHeight - denomLine;

      frac = new VBox({
        individualShift: [
          {
            box: denomBox,
            shift: denomShift,
            classes: [...classes, align(this.align)],
          },
          { box: fracLine, shift: -denomLine, classes },
          {
            box: numerBox,
            shift: -numerShift,
            classes: [...classes, align(this.align)],
          },
        ],
      }).wrap(fracContext);

      // console.log('denom', denomBox.height, denomBox.depth);
      // console.log('fracline', fracLine.height, fracLine.depth);
      // console.log('numer', numerBox.height, numerBox.depth);
      // console.log('frac', frac.height, frac.depth);
      // console.log(
      //   'expected',
      //   denomBox.height + denomBox.depth + fracLine.height,
      //   numerBox.height + numerBox.depth + fracLine.depth
      // );
    }

    // Rule 15e of Appendix G
    const delimSize = fracContext.isDisplayStyle
      ? metrics.delim1
      : metrics.delim2;

    // Optional delimiters
    const leftDelim = this.leftDelim
      ? this.bind(
          context,
          makeCustomSizedDelim(
            'open',
            this.leftDelim,
            delimSize,
            true,
            context,
            { style: this.style, mode: this.mode, isSelected: this.isSelected }
          )
        )
      : makeNullDelimiter(fracContext, 'ML__open');

    let rightDelim: Box | null = null;
    if (this.continuousFraction) {
      // Zero width for `\cfrac`
      rightDelim = new Box(null, { type: 'close' });
    } else if (!this.rightDelim)
      rightDelim = makeNullDelimiter(fracContext, 'ML__close');
    else {
      rightDelim = this.bind(
        context,
        makeCustomSizedDelim(
          'close',
          this.rightDelim,
          delimSize,
          true,
          context,
          { style: this.style, mode: this.mode, isSelected: this.isSelected }
        )
      );
    }

    // TeXBook p. 170 "fractions are treated as type Inner."

    const mfrac = new Box([leftDelim, frac, rightDelim], {
      isTight: fracContext.isTight,
      type: 'inner',
      classes: 'ML__mfrac',
    });

    const result = this.bind(context, mfrac);
    if (this.caret) result.caret = this.caret;

    return this.attachSupsub(context, { base: result });
  }
}

function align(v: 'left' | 'right' | 'center'): string {
  return (
    {
      left: 'ML__left',
      right: 'ML__right',
      center: 'ML__center',
    }[v] ?? 'ML__center'
  );
}

import type { CreateAtomOptions, AtomJson } from 'core/types';
import { Atom } from '../core/atom-class';
import { makeSVGBox, Box } from '../core/box';
import { Context } from '../core/context';
import { X_HEIGHT } from '../core/font-metrics';
import { VBox } from '../core/v-box';

export class AccentAtom extends Atom {
  readonly accent?: number;
  private readonly svgAccent?: string;
  constructor(
    options: CreateAtomOptions & {
      accentChar?: number;
      svgAccent?: string;
      body: null | readonly Atom[];
    }
  ) {
    super({ ...options, type: 'accent', body: options.body ?? undefined });
    if (options.accentChar) this.accent = options.accentChar;
    else this.svgAccent = options?.svgAccent;

    this.skipBoundary = true;
    this.captureSelection = true;
    // this.limits = 'accent'; // This will suppress the regular
    // supsub attachment and will delegate
    // it to the decomposeAccent
    // (any non-null value would do)
  }

  static fromJson(json: { [key: string]: any }): AccentAtom {
    return new AccentAtom(json as any);
  }

  toJson(): AtomJson {
    return {
      ...super.toJson(),
      accentChar: this.accent,
      svgAccent: this.svgAccent,
    };
  }
  render(parentContext: Context): Box {
    // > Math accents, and the operations \\sqrt and \\overline, change
    // > uncramped styles to their cramped counterparts; for example, D
    // > changes to D′, but D′ stays as it was. -- TeXBook p. 152

    const context = new Context(
      { parent: parentContext, mathstyle: 'cramp' },
      this.style
    );
    // Accents are handled in the TeXbook pg. 443, rule 12.

    //
    // 1. Build the base atom
    //
    const base =
      Atom.createBox(context, this.body) ?? new Box('□', { style: this.style });

    //
    // 2. Skew
    //
    // Calculate the skew of the accent.
    // > If the nucleus is not a single character, let s = 0; otherwise set s
    // > to the kern amount for the nucleus followed by the \\skewchar of its
    // > font.
    // Note that our skew metrics are just the kern between each character
    // and the skewchar.
    let skew = 0;
    if (
      !this.hasEmptyBranch('body') &&
      this.body!.length === 2 &&
      this.body![1].isCharacterBox()
    )
      skew = base.skew;

    //
    // 3. Calculate the amount of space between the base and the accent
    //
    let clearance = Math.min(base.height, X_HEIGHT);

    //
    // 4. Build the accent
    //
    let accentBox: Box;
    if (this.svgAccent) {
      accentBox = makeSVGBox(this.svgAccent);
      clearance = context.metrics.bigOpSpacing1 - clearance;
    } else if (this.accent) {
      // Build the accent
      const accent = new Box(this.accent, { fontFamily: 'Main-Regular' });
      // Remove the italic correction of the accent, because it only serves to
      // shift the accent over to a place we don't want.
      accent.italic = 0;

      // Some of the accents are combining characters, and
      // thus shows up much too far to the left. To account for this, we add a
      // specific class which shifts the accent over to where we want it.
      const correctionClass =
        // this.accent === 94 || // ^
        this.accent === 0x20d7 || // \\vec
        this.accent === 0x20db || // \\ddot
        this.accent === 0x20dc // \\tilde
          ? ' ML__accent-combining-char'
          : '';
      accentBox = new Box(accent, {
        classes: 'ML__accent-body' + correctionClass,
      });
    }

    //
    // 5. Combine the base and the accent
    //

    // Center the accent over the base character, accounting for width differences
    // and applying the skew correction for italic fonts.
    // The formula is: (baseWidth - accentWidth) / 2 to center, then add base.left
    // for any existing margin, then add 2*skew for italic correction.
    // We use 2*skew because the accent is centered, so adding to marginLeft
    // effectively shifts the accent to the right by half that amount.
    const accentMargin =
      (base.width - accentBox!.width) / 2 + base.left + 2 * skew;

    accentBox = new VBox({
      shift: 0,
      children: [
        { box: new Box(base) },
        -clearance,
        {
          box: accentBox!,
          marginLeft: accentMargin,
          classes: ['ML__center'],
        },
      ],
    });

    // Use an `ord` box type so inter-box spacing with following relations
    // (e.g. `\hat{x}=`) matches regular atom spacing.
    const result = new Box(accentBox, { type: 'ord' });
    if (this.caret) result.caret = this.caret;
    this.bind(context, result.wrap(context));
    return this.attachSupsub(context, { base: result });
  }
}
